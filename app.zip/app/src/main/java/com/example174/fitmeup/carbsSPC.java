package com.example174.fitmeup;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class carbsSPC extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carbs_spc);


    }


}
